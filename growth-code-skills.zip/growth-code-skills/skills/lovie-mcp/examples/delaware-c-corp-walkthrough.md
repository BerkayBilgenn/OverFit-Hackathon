# Response-pattern template: forming a Delaware C-Corp

This is a **template** showing the SHAPE of a Lovie formation conversation — the response style, the safety gates, the order of operations. It contains NO specific tool names, dollar amounts, IDs, or other values that have not been verified against the live `lovie` MCP. Every concrete value is rendered as a `<placeholder>` so it is obvious what comes from the runtime tool response.

When Claude runs a real formation, it replaces every `<placeholder>` with the actual value returned by the tool it just called.

Read this once before running a real formation to internalize the pattern.

---

## Setup assumption

- User: solo founder, wants to incorporate
- Lovie not yet installed
- Tool: Claude Code

---

**User:** I want to start a Delaware C-Corp called "Acme Robotics" — I'll be the sole owner. Can you set everything up?

**Claude:**

I'll walk you through this step by step. Before I can form the company, I need to install the Lovie MCP and have you log in. Two steps:

1. Start the login process — it opens a browser for you to sign in with your lovie.co account.
2. Wire Lovie into Claude Code as an MCP, restart, and form the company.

Do you already have a lovie.co account, or do you need to sign up first?

---

**User:** I already have one.

**Claude:** Starting login. A browser tab will open.

*[Calls `npx -y lovie login` in background; monitors output]*

Browser opened. Complete the sign-in there — you have ~2 minutes before the OAuth flow times out.

---

**User:** done.

**Claude:**

*[Verifies with `npx -y lovie status` → confirms the output does NOT contain `Not logged in` (the only verified status string)]*

Logged in (status reports an authenticated session). Now wiring Lovie into Claude Code:

```
claude mcp add --scope user lovie -- npx -y lovie
```

*[Runs the command]*

Wired. **You need to restart Claude Code** so Lovie's tools appear. Restart and come back — we'll form the company then.

---

**User:** restarted.

**Claude:**

*[Calls `tools/list` against `lovie` MCP server. Caches the response. Identifies the tools matching each formation step by their `description` field — does not guess names. If only `lovie_auth_required` is returned, treats that as a "not logged in" signal and stops.]*

Lovie's online. Available tools loaded. Let's form Acme Robotics. The plan:

```
Formation progress:
- [ ] 1. Start a formation session
- [ ] 2. Set state → Delaware
- [ ] 3. Set entity type → C-Corp
- [ ] 4. Check name availability → "Acme Robotics, Inc."
- [ ] 5. Add you as sole shareholder (100%)
- [ ] 6. Generate Certificate of Incorporation
- [ ] 7. Pay filing fee (I'll show the amount from the tool response before paying)
```

Starting.

*[Calls the formation-start tool → response contains a reference field]*

Formation session created (`<formation-reference-from-response>`).

*[Calls the state tool with the Delaware enum value from its input schema]*

State set to Delaware.

*[Calls the entity-type tool with the C-Corp enum value from its input schema]*

Entity type set to C-Corp.

*[Calls the name-availability tool with `"Acme Robotics, Inc."`]*

Checking name availability for "Acme Robotics, Inc."... `<available-or-taken-from-response>`. If taken, propose 2–3 variants and recheck.

Now I need your info to add you as the sole shareholder. The shareholder-add tool's input schema requires (verify from `tools/list`):

- Your full legal name (as on your government ID)
- The email on this lovie.co account (or a different one if you prefer)

Ownership will be 100%.

---

**User:** Provides legal name and email.

**Claude:**

*[Calls the shareholder-add tool with the user's name, email, and percentage 100. Validates running sum after the call.]*

Shareholder added. Running sum: 100% ✓

Now I'll generate the Certificate of Incorporation. **I'll show it to you for review before we pay any filing fee.**

*[Calls the certificate-generation tool → returns a document URL or reference]*

Certificate generated: `<certificate-url-from-response>`

Please open it and confirm:

- Company name: **Acme Robotics, Inc.**
- State: **Delaware**
- Entity: **C-Corp**
- Shareholder: **`<legal-name-from-user>` (100%)**

If anything is wrong, tell me and I'll fix it BEFORE we pay. Amendments after filing cost extra.

---

**User:** looks good.

**Claude:**

*[Calls the filing-fee quote tool, or reads the fee from the formation session's state. Surfaces the EXACT amount the tool returned — does not assert a number from any other source.]*

Ready to pay the Delaware filing fee:

- Amount: **`<fee-amount-from-tool>` USD**
- Non-refundable
- Pays from your lovie.co default payment method

Confirm "pay" and I'll execute.

---

**User:** pay

**Claude:**

*[Calls the filing-fee-pay tool → returns payment confirmation, possibly EIN and state filing receipt. Pulls actual values from the response.]*

Paid. Acme Robotics, Inc. is being filed.

```
Formation progress:
- [x] 1. Formation session (<formation-reference-from-response>)
- [x] 2. State: Delaware
- [x] 3. Entity: C-Corp
- [x] 4. Name: Acme Robotics, Inc. (available)
- [x] 5. Sole shareholder <legal-name-from-user> (100%)
- [x] 6. Certificate generated
- [x] 7. Filing fee paid: <fee-amount-from-tool> USD
```

**Next steps** (using whichever info the tool returned):

- Filing processing time: `<from-tool-response-or-direct-to-lovie.co>`.
- EIN: `<from-tool-response-when-available>`. Some tools return the EIN later — surface it when it arrives.
- Once filed, the user can open a business bank account (Banking AI — Coming Soon; check `tools/list` for available bank tools).

Want me to check whether a bank-account tool is exposed in `tools/list` and try opening a checking account now, or are we done for today?

---

## What this template demonstrates

- **One question at a time.** Claude asks for one piece of info at each step, doesn't dump a wall of questions.
- **Money confirmation from the tool response.** Before the filing-fee call, Claude shows the dollar amount the tool returned — never an assumed number.
- **Certificate review.** Before pay, Claude shows the certificate URL the tool returned and asks for confirmation.
- **Status updates, not JSON.** Claude says "Formation session created" with the reference, rather than dumping the raw response.
- **Real tool names from `tools/list`.** The template uses placeholder language like "the formation-start tool" — Claude looks up the real name at runtime via `tools/list`.
- **Checklist usage.** The 7-step checklist is copied into the response and updated as steps complete.
- **Next-step suggestion at the end.** Doesn't dead-end; offers what's logical next.
- **Placeholder syntax for runtime values.** Every `<from-tool>` placeholder marks a value that ONLY exists at runtime. The template never asserts specific fee amounts, IDs, or processing times.

## Anti-patterns to avoid

- ❌ Paying the filing fee without showing the dollar amount the tool returned
- ❌ Generating the certificate without asking the user to review it
- ❌ Dumping the raw PDF URL and waiting silently — instead, walk through what to check
- ❌ Asking for name, state, entity type, and email all at once
- ❌ Surfacing the raw JSON of every tool response
- ❌ Assuming the email on the lovie account is the right one for the shareholder record (could differ)
- ❌ Inventing a fee amount, processing time, or tool name not returned by a live tool response
