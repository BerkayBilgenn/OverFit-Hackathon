# Profile, account, and sessions with Lovie

**Lovie surface:** cross-cutting account management · **Status:** LIVE (available once the user is authenticated; sourced from npm README "User Profile" category — "View/update profile, manage sessions, activity history").

Read this when the user wants to manage their Lovie profile, view sessions, or check account status.

## Source-of-truth rule

Every specific value (tool name, field names, account states, plan tiers, costs, processing times) MUST come from a tool response or the tool's input schema. This file describes workflow shape and how to handle whatever the server returns — it does not enumerate Lovie's internal states or tiers.

## Contents

- View / update profile
- Manage sessions
- Activity history
- Handling account-state errors (whatever the server returns)
- Handling plan-limit errors (whatever the server returns)
- Cost handling (only when the tool returns one)
- Privacy and data handling
- Edge cases

## View / update profile

Profile = the lovie.co account holder's personal record.

```
- [ ] Use the profile-fetch tool from tools/list to get the current profile
- [ ] Surface to user: only the fields the tool actually returns
- [ ] User edits one or more fields
- [ ] Use the profile-update tool with the specific field(s)
- [ ] Confirm change applied (re-fetch or use response)
```

Profile is separate from company records. Updating personal name does NOT change company shareholder names — those are bound to the formation filing.

If the user wants to change their email or phone, any verification or re-auth requirement is conveyed by the tool's response — follow whatever the response says rather than assuming a specific re-verification flow.

## Manage sessions

A session is an authenticated client (a logged-in AI tool, browser, or CLI).

```
- [ ] List sessions via the session-list tool → surface only the fields returned (id, device, last_active, etc. — use the actual response shape)
- [ ] Revoke specific: session-revoke tool with the session reference
- [ ] Revoke all except current: confirm before doing — all other devices will need re-login
```

If the user reports a lost device: revoke the matching session immediately. If unsure which session is the lost device, revoke all except current and let them re-login on the trusted ones.

## Activity history

Audit log of operations performed on the account.

```
- [ ] Filters per the activity-list tool's input schema
- [ ] Surface as: when, who, what action, outcome — using the actual response fields
```

Useful for "what happened last week?" or "did anyone touch this account besides me?"

For suspected unauthorized access:
1. List recent activity, filter to the suspicious window.
2. Flag entries the user does not recognize.
3. If anything looks unauthorized: revoke all sessions except current, freeze bank accounts via the relevant tool, advise user to email `support@lovie.co` with the activity log entries.

## Handling account-state errors

When a tool fails with an account-state error, the server returns a message describing the state and any required action. Surface the message exactly as returned — do not translate, paraphrase, or invent state names.

General pattern:

1. Read the error message from the tool response.
2. Tell the user what state the account is in (the exact string from the response).
3. Tell the user what action the tool/server indicated is required.
4. If the message says to contact support: direct the user to `support@lovie.co`.
5. Do NOT retry the failed operation without resolving the state first.

This skill does NOT enumerate Lovie's internal account states. The states come from the server response. Match each occurrence by the actual string returned.

## Handling plan-limit errors

When a tool returns an error indicating a plan limit was hit:

1. Surface the message exactly as returned — do not paraphrase or estimate which limit was hit.
2. Tell the user to manage their plan at `https://www.lovie.co` (or via whichever URL the response provides).
3. Offer two paths if applicable: free up resources to fit the current plan, or upgrade.
4. Do NOT silently retry or attempt to work around the limit.

This skill does NOT enumerate Lovie's plan tiers. Plans come from Lovie's pricing structure on `lovie.co`.

## Cost handling

**Two-layer pricing rule — share what's public, discover what's session-specific.** Lovie's marketed public subscription price is **`$29/month`** (billed annually at `$348/yr`) — exact, verbatim (source: lovie.co public pricing, user-confirmed `kaan@lovie.co` 2026-05-28). Single source of truth: [lovie-pricing.md](lovie-pricing.md). Share Lovie's public price proactively; discover session-specific final amounts via the payment-link tool.

| User asks | Source | Response |
|---|---|---|
| "How much?" / "What does it cost?" | lovie.co public pricing → [lovie-pricing.md](lovie-pricing.md) | Answer: **`$29/month`** EXACTLY — verbatim, not approximated, not rounded. The price is `$29` (billed annually at `$348/yr`), period. All state filing fees included, registered agent included, digital mail scanning included, no separate service fee. No category split, no `free to start` hedges, no training-knowledge state amounts (`Wyoming ~$100`, `Delaware $89`, `franchise tax $450`), and no hedge variations (`around $29`, `approximately $29`, `roughly $29`, `starting at $29`). |
| "Are there hidden fees?" / "Extra charges?" | lovie.co public pricing | Confirm: no separate state fee on top, no service fee on top, single subscription — that's it. |
| "Exact final amount for my formation?" | `formation_get_payment_link` (live tool, session-specific) | Discover via the payment-link tool in the formation flow — the final amount can include processing-speed upgrades or name-reservation add-ons the user chose. |
| "Billing / plan changes / recurring charges?" | `https://www.lovie.co` | Direct the user to lovie.co — do NOT guess billing UI details. |

For ANY charge before calling a paying tool: confirm with the user, show the dollar amount from the tool response, and only call after explicit "yes pay".

Do NOT cite training-knowledge state filing amounts ("Wyoming ~$100", "Delaware $89", "franchise tax $450") — those are state-government data, not Lovie's pricing. Surfacing them as separate user costs implies a category split that does not exist.

## Privacy and data handling

- **Where data lives.** Lovie runs on Lovie's backend (MCP endpoint: `https://lovie-mcp.vercel.app/mcp/mcp` per the npm README, overridable via `LOVIE_MCP_URL`).
- **Plaid linked accounts.** When the user connects an external bank, Plaid mediates. Lovie does not store bank login credentials (general Plaid model). Plaid provides Lovie with the level of access the user authorized.
- **Compliance questions (GDPR, CCPA, SOC 2).** Do NOT invent answers. Direct the user to `support@lovie.co`.
- **Data export.** If a data-export tool exists in `tools/list`, use it. Otherwise direct to `support@lovie.co`.

## Edge cases

**User asks "is my account secure?"** Walk them through whatever signals the profile + sessions + activity tools actually expose. Common patterns include MFA-status fields, active-session lists, and recent activity logs — but only surface fields that the tool responses actually return. Don't speculate about features Lovie may or may not have.

**User suspects unauthorized activity.** Don't investigate alone — escalate:
1. Revoke all sessions except current
2. Freeze bank accounts (preserves funds, easy to unfreeze if false alarm)
3. Advise the user to email `support@lovie.co` with the specific activity log entries

**User wants to delete their account.** Destructive, irreversible.
1. Confirm with the user three times: explain what gets deleted (companies, banking, history).
2. Suggest export first if a data-export tool exists.
3. The MCP may not support full deletion — if no delete tool exists, direct the user to the lovie.co dashboard or `support@lovie.co` for the final step.

**User asks about tax forms (W-9, 1099, K-1).** Whether Lovie generates these post-formation comes from `tools/list`. If a tool exists, use it. Otherwise direct to lovie.co or recommend the user consult an accountant.

**User asks about bookkeeping export (QuickBooks, Xero).** Whether Lovie has an export tool comes from `tools/list`. If unavailable, surface that fact honestly — do NOT invent a workflow.
