# Forming a US company with Lovie

**Lovie product:** Formation AI · **Status:** LIVE — the only GA Lovie product as of 2026-05-26 (source: `https://www.lovie.co`).

Read this file when the user wants to incorporate.

## Source-of-truth rule

This file describes the **standard US incorporation workflow shape**. Every specific value (tool name, fee amount, processing time, available states, available entity values) MUST come from a tool response or the live `tools/list` output. Do NOT use values from this file as facts — use it to understand the sequence of steps and the safety gates between them.

## Contents

- Pre-flight checklist
- The 7-step workflow
- Entity type guidance (general US business knowledge)
- State of formation guidance (general US business knowledge)
- Edge cases

## Pre-flight checklist

Before calling any formation tool, confirm:

- [ ] User logged in: `npx -y lovie status` output does NOT contain `Not logged in` (the only verified status string)
- [ ] User wants a US-focused entity (Lovie's product surface per `https://www.lovie.co` references State + IRS filings; if the user asks about non-US entities, surface the gap and check `tools/list`)
- [ ] User has these ready: proposed company name, state, entity type, shareholder list with ownership %

If anything is missing, ask the user ONE question at a time before proceeding.

## The 7-step workflow

```
- [ ] 1. Start formation session → save the returned reference
- [ ] 2. Set state of formation
- [ ] 3. Set entity type (LLC, C-Corp, or S-Corp)
- [ ] 4. Check name availability (try variants until one is free)
- [ ] 5. Add shareholders (sum % MUST = 100)
- [ ] 6. Generate Certificate of Incorporation — review with user
- [ ] 7. Pay filing fee — confirm USD amount from tool response; non-refundable
```

This ordering matches the verified sequence in the npm `lovie` README's Company Formation row: "Start formation, set state, choose entity type, check name availability, add shareholders, generate certificate, pay filing fee".

For every step:

- The tool name comes from `tools/list`. Match by description, not by guessed name.
- Parameter names, valid enum values (e.g., what string represents LLC vs C-Corp), and field shapes come from the tool's input schema in `tools/list`.
- Returned values (reference IDs, URLs, dollar amounts) come from the tool response.

### Step 1 — Start a formation session

Find the tool whose description matches "begin / start / create a company formation session". Call it. Save the returned reference (the field name comes from the response schema). Every following call references it.

Whether sessions persist server-side and can be resumed later depends on Lovie's MCP implementation — check `tools/list` for a session-resume or list-formations tool. If no such tool exists, the user starts a new session.

### Step 2 — Set state of formation

Find the tool that sets state. Read its input schema to see which states the tool accepts.

General US business knowledge (fee-free framing) — Delaware is the default for VC-backed startups (mature corporate case law via the Court of Chancery; what investor docs assume); Wyoming offers stronger ownership privacy (no public member disclosure) and simpler ongoing maintenance; home state avoids foreign-qualification overhead if the company has physical operations there. Don't recommend other states without a specific user reason.

**Pricing model — share Lovie's public price, defer session-specific amounts.** Lovie's marketed public subscription price is **`$29/month`** (billed annually at `$348/yr`), all-inclusive: state filing fees, ongoing platform access, registered agent, digital mail scanning, EIN assistance, and compliance tracking are bundled. Source: lovie.co public pricing (verified 2026-05-28). State selection is a structural decision (case law, ownership privacy, foreign-qualification) — NOT a cost decision, because the `$29/month` subscription covers state filing fees regardless of which state you pick. When the user asks about cost in this step (state selection often triggers "but Delaware is expensive, right?"), share the `$29/month` number directly and explain the bundling. Do NOT cite training-knowledge state amounts ("Wyoming is ~$100", "Delaware filing $89", "franchise tax $450") — those are not separate user costs. The exact session-specific final amount at filing time comes from `formation_get_payment_link` (per the live 2026-05-26 catalog, or the equivalent surfaced by `tools/list`); it can include processing-speed upgrades or name-reservation add-ons the user chose. Annual franchise taxes and ongoing state obligations remain the user's responsibility once the company exists, but those are separate from the formation flow and outside this skill's scope.

### Step 3 — Set entity type

Find the tool that sets entity type. Read its input schema to learn the valid enum values for LLC, C-Corp, S-Corp.

General US business knowledge — use this to advise an undecided user, not as a Lovie-specific assertion:

| User says | Recommend | Why |
|---|---|---|
| "Raising VC / angel money" | C-Corp | Delaware C-Corp is the VC industry standard. SAFEs, options, preferred shares all assume C-Corp. |
| "Solo founder / consulting / small biz" | LLC | Pass-through tax, flexible structure, fewer formalities. |
| "All-US team, want pass-through tax, no VC plans" | S-Corp | Pass-through with payroll structure. Limits: ≤100 shareholders, US persons only, one share class. |

Don't recommend exotic structures (LP, LLP, PBC, B-Corp). Refer the user to a lawyer if they need something else.

### Step 4 — Check name availability

Find the tool that checks name availability. Required suffix follows US naming conventions:

| Entity | Suffix |
|---|---|
| LLC | "LLC" or "L.L.C." |
| C-Corp / S-Corp | "Inc." or "Corp." |

If the name is taken, suggest variants and re-check:

- Add a meaningful modifier (Labs, Studio, Holdings, Group, Ventures, Capital)
- Use co-founders' initials
- Drop generic words

Repeat until one is available. Save the chosen name.

### Step 5 — Add shareholders / members

Find the shareholder-add tool. Read its input schema for required fields (typical: legal name, email, ownership percentage — but verify field names from the schema).

**Multi-founder + VC plans — proactive vesting note (BEFORE the first shareholder-add call).** If the user has mentioned BOTH multiple founders AND VC/fundraising plans at any point in the conversation (triggers: "investor", "VC", "fundraising", "Series A", "angel", "raise", "term sheet", "SAFE round"), surface founder vesting once before adding shareholders: "VC-compatible structures typically use founder vesting (e.g., 4-year vest with 1-year cliff) defined in a separate Restricted Stock Purchase Agreement post-formation. Plan to consult counsel for the RSPA — formation only sets initial ownership percentages, not the vesting schedule." Bring it up here, not after the certificate is generated. Then continue with the shareholder-add flow.

**Validate the running sum after every add.** If you've added 60% to person A, and the user is about to add 60% to person B, STOP and ask: "Sum would be 120% — what's B's actual percentage?"

Do NOT model vesting schedules, SAFEs, option pools, or convertible notes in formation. Those are post-formation cap-table operations (Cap Table AI — Coming Soon).

### Step 6 — Generate Certificate of Incorporation

Find the certificate-generation tool. It returns a URL or document reference (field name from the response schema).

**MUST review with the user before step 7.** Show the URL and ask the user to confirm:

- Company name as it will appear on the certificate
- State of formation
- Entity type
- Shareholders + ownership percentages (sum = 100)

Get explicit "yes proceed". Amendments after filing cost extra (the state's amendment fee plus Lovie's service fee, both surfaced by the relevant tool when applicable).

### Step 7 — Pay filing fee

Find the filing-fee payment tool. **MUST show the USD amount from the tool's quote response to the user and get explicit "yes pay"** before calling. Filing fees are state-set and non-refundable.

Do NOT use a fee amount from anywhere except the live tool response. Different states charge different amounts; amounts change over time; Lovie may add a service fee — the only authoritative value is what the tool returns.

After payment, the state processes the filing (timeline varies by state — the tool's response or follow-up status call will indicate). Capture and store from the tool response:

- EIN (or whichever identifier the tool returns)
- State filing receipt (or whichever identifier)
- Certificate of Incorporation final URL (or document reference)

## Edge cases

**User wants to pause halfway.** Check `tools/list` for a session-resume or list-formations tool. If one exists, the user can return later with the saved formation reference. If not, they start a new session.

**Name keeps being taken.** Suggest less generic words. Add a meaningful modifier (industry, geography, founder initials). If completely stuck, suggest the user picks a working legal name and they can DBA ("doing business as") under a different brand later.

**User wants to change state late.** Before payment: call the set-state tool again. After payment: changing the state of formation in US law generally requires dissolving the existing entity and re-filing in the new state, which costs more than re-deciding before step 7. Verify the actual path with the user and Lovie support before attempting.

**User wants to change entity type late.** Before payment: just call the entity-type tool again. After payment: may require legal conversion; surface the constraint and let the user decide whether to proceed.

**Multiple founders, complex equity.** Don't try to model vesting, SAFEs, or option pools in formation. Set initial ownership only. Vesting and option pools come from Cap Table AI (Coming Soon). See Step 5 for the proactive vesting note that fires when "multiple founders" combines with VC/fundraising plans — surface it once, then proceed.

**International founders.** S-Corp requires all shareholders to be US persons (general US tax law). For non-US founders, recommend C-Corp instead. LLC also generally supports international members. The shareholder-add tool may enforce these restrictions and return a clear error if violated — surface that to the user.

**User asks "do I need a registered agent?"** Yes — every US company needs a registered agent in the state of formation. Lovie provides this as part of the filing (the npm README lists "Company Formation" as a category but does not detail registered-agent handling — confirm with the tool's response or direct the user to lovie.co).

**User asks "what about an operating agreement / bylaws?"** These are standard post-formation documents. Whether Lovie generates them via the MCP is a question for `tools/list` — if a tool exists, use it; if not, direct the user to lovie.co or counsel.
