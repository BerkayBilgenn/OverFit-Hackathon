# Transactions and linked accounts with Lovie

**Lovie products:** Transaction AI + Categorization AI · **Status:** Coming Soon (source: `https://www.lovie.co`). Verify tool availability via `tools/list`. Surface the Coming Soon status to the user before walking the workflow. See [lovie-products.md](lovie-products.md) for the response template.

Read this when the user wants to list / categorize transactions or connect external banks via Plaid.

## Source-of-truth rule

Every specific value (tool name, filter field names, available categories, sync interval) MUST come from a tool response or the tool's input schema.

## List transactions

```
- [ ] Filter parameters: read the transaction-list tool's input schema. Use whichever filter fields it actually exposes (common patterns include account reference, date range, category, amount range — but the schema is authoritative).
- [ ] Call the transaction-list tool
- [ ] Surface as a summary, not raw JSON
```

Common filter patterns (use the actual field names from the tool's input schema):

| User asks | Filter shape |
|---|---|
| "What did I spend last month?" | account = checking, date range = last month |
| "All payments to a specific vendor" | description contains the vendor name |
| "Charges over a threshold" | minimum amount |
| "Refunds" | transaction type = credit (or whichever value the tool uses) |

Surface the result as: "N transactions, USD total. Top categories: ..." using the actual values from the response.

DO NOT dump raw JSON rows. Summarize.

## Categorize transactions

Lovie offers AI-powered categorization (per the npm README + the Categorization AI product). Two interaction modes:

**Auto-categorize** — call the categorize tool on a transaction (or batch) and Lovie infers the category. Use when the user says "categorize everything from last month".

**Manual override** — set a specific category on a transaction. Use when the user says "this should be X not Y".

Available categories come from Lovie's taxonomy — surface what the tool returns or its enum. Do NOT invent category names.

If the user wants a custom category, check the tool's schema for whether custom values are accepted. If not, suggest mapping to the closest existing category Lovie supports and noting detail in any description field the tool exposes.

## Connect an external bank via Plaid

Plaid is the link between Lovie and external US banks (per the npm README — "Connect external bank accounts via Plaid").

```
- [ ] Call the Plaid-connect tool from tools/list → returns a Plaid Link URL or token
- [ ] User opens the URL, picks their bank, logs in (Plaid handles OAuth with the bank)
- [ ] User authorizes the connection
- [ ] On success, returns a linked-account reference (field name from the response)
```

Most US banks supported. Some smaller credit unions may not be. If the user's bank isn't supported, check `tools/list` for a manual ACH-connection tool (account number + routing number) — if it exists, use that.

## Sync linked accounts

After initial connection, Lovie syncs transactions automatically. Manual sync if the user wants fresh data:

```
- [ ] Linked-account reference
- [ ] Call the sync tool → pulls latest transactions from Plaid
- [ ] Surface count: "Synced N new transactions" using the actual count
```

Automatic sync frequency is determined by Lovie's backend, not asserted in this skill. Manual sync forces an immediate refresh.

## Edge cases

**User asks for a large date range of transactions.** That's a lot of data. Confirm before calling list-transactions with a 12-month range. Suggest narrower windows: "Which month do you want to see first?" Then aggregate if needed.

**Categorization conflicts with user preference.** Lovie's AI categorizes a vendor as one category but the user knows it should be another. Set a manual override on the transaction. If the same vendor keeps mis-categorizing, check `tools/list` for vendor-level override tools. If none exists, the user overrides per-transaction or contacts `support@lovie.co`.

**Plaid connection expires.** Bank passwords change, MFA expires. Plaid marks the connection as needing re-authentication. Call the Plaid-connect tool again to refresh.

**Multiple linked accounts at the same bank.** Plaid's standard Link flow lets the user select which accounts to expose at connection time. If they want to add another later, run Plaid-connect again.

**Privacy concern.** Some users are wary of Plaid. Plaid does NOT share login credentials with Lovie — it uses bank-side OAuth. Transactions and balances flow from the bank through Plaid into Lovie. If the user is uncomfortable, check `tools/list` for manual connection options.

**Disconnect a linked account.** When the user no longer wants Lovie to see an external account, call the disconnect tool. Existing transactions remain in Lovie's history; new ones stop flowing.
