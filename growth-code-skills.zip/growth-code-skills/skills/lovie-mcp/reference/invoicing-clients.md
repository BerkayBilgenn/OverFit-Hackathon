# Invoicing and clients with Lovie

**Lovie product:** Invoicing AI · **Status:** Coming Soon (source: `https://www.lovie.co`). Run `tools/list` (or `bash scripts/fetch-tool-names.sh`) to see which invoicing tools are actually exposed. Surface the Coming Soon status to the user and only proceed if a matching tool exists. See [lovie-products.md](lovie-products.md) for the response template.

Read this when the user wants to create invoices or manage client records.

## Source-of-truth rule

Every specific value (tool name, field names, status values, currency support, payment methods) MUST come from a tool response or the tool's input schema.

## Contents

- Prerequisites
- Create a client
- Create an invoice
- Send, mark paid, duplicate
- Generate PDF
- Edge cases

## Prerequisites

Invoicing does NOT require a formed company — invoices can be issued from any Lovie account. However, the issuing entity on the invoice reflects either the user's profile or a formed company. Confirm which entity is the issuer before creating an invoice with significant tax implications.

## Create a client

A client is a customer record — the entity you'll invoice. Reusable across invoices.

```
- [ ] Required fields: read the client-create tool's input schema. Use whichever fields it marks as required (common patterns include name and email — but the schema is authoritative).
- [ ] Optional fields: billing address, tax ID, payment terms, currency
- [ ] Create → save the returned client reference
```

Before creating, search existing clients via the client-list tool. If the user says they want to invoice an existing customer, check if that customer is already in the system. If yes, use the existing client reference. If no, ask the user for the email before creating.

## Create an invoice

```
- [ ] Pick or create client → client reference
- [ ] Line items: each with a description, quantity, unit price (USD)
- [ ] Due date (the tool's input schema may define a default — use that)
- [ ] Optional: notes, terms, tax rate
- [ ] Create via the invoice-create tool → save the returned invoice reference. The created state (draft, sent, etc.) is whatever the tool's response indicates.
```

Total = sum of (quantity × unit_price), plus tax if applicable. The tool may compute the total in its response — use that, not your own arithmetic, if the response provides it.

Draft invoices are NOT sent automatically. They exist server-side until you send them.

## Send an invoice

```
- [ ] Confirm the draft is correct (line items, total, due date, client email)
- [ ] Send via the invoice-send tool → invoice delivered with a hosted payment link
- [ ] Status transitions per the tool's response
```

After sending, the client receives an email with a link to view the invoice and pay. Lovie hosts the payment page. Payment methods come from the tool's response or Lovie's account configuration.

## Mark invoice paid

When funds arrive:

```
- [ ] Verify payment actually received (check the relevant account's transactions)
- [ ] Use the invoice-mark-paid tool → status transitions
- [ ] Optional: record payment method, payment date, transaction reference per the tool's input schema
```

DO NOT mark paid without verifying receipt — it creates accounting drift. If the user says they were paid but no matching deposit is visible in any account, ask: "Where did the payment land? Which account?"

## Duplicate an invoice

For recurring billing or similar work for the same client:

```
- [ ] Source invoice reference
- [ ] Use the invoice-duplicate tool → new draft with the same line items
- [ ] Adjust line items / due date / amounts as needed
- [ ] Send when ready
```

## Generate PDF

For invoices already created:

```
- [ ] Invoice reference
- [ ] Call the PDF-generation tool → returns a URL or document reference
- [ ] Surface URL to user for download or email
```

Whether the "send invoice" tool attaches a PDF automatically depends on its implementation — check its input/output schema. Use the PDF-generation tool explicitly when the user wants a standalone PDF (e.g., to attach in Slack).

## Edge cases

**User says "invoice X for Y dollars".** Don't immediately create. Ask for line item details: "What's the description? Hours / fixed fee / something else?" An invoice with a generic description ("Services") is professionally weak and may delay payment.

**Multiple currencies.** Lovie's default is USD. If the client is international, ask whether to bill in USD (simpler) or local currency (better for the client). Whether the tool supports multi-currency comes from its input schema.

**Recurring invoices.** Whether a recurring-invoice tool exists comes from `tools/list`. If yes, use it. If not, use the duplicate-invoice tool each cycle and remind the user to set their own reminder.

**Late payments.** Lovie may send automatic reminders — verify from the tool's behavior or documentation. If a tool exposes invoice-status filters, list overdue invoices and surface them to the user.

**Disputes / refunds.** If a client disputes a paid invoice, this involves: refund the payment, void or credit the invoice. Check `tools/list` for a refund tool. Confirm with user before refunding.

**Tax handling.** Sales tax, VAT, GST — depend on entity, state, and client location. If the user asks "should I charge tax on this invoice?", do NOT guess. Refer them to an accountant. The tool may accept a tax rate field but won't tell them whether to apply one.

**Invoice the wrong client.** If a sent invoice went to the wrong client, void or delete it (depending on tool support) and create a new one. The wrong client may have already received the email — apologize via email if relevant.
