# Banking, cards, and payments with Lovie

**Lovie products:** Banking AI + Corporate Cards AI + Credit Card AI · **Status:** Coming Soon (source: `https://www.lovie.co`). Run `bash scripts/fetch-tool-names.sh` to see which tools are exposed in the MCP catalog. Before any workflow below, surface the Coming Soon status to the user and only proceed if `tools/list` confirms a matching tool exists. See [lovie-products.md](lovie-products.md) for the response template.

Read this when the user wants to open accounts, issue cards, or move money.

## Source-of-truth rule

Every specific value (tool name, account type, card limit type, transfer speed, fee) MUST come from a tool response or the tool's input schema. This file describes workflow shape only.

## Contents

- Prerequisites
- Open a bank account
- Issue a card
- Transfer / deposit / withdraw
- Freeze, close, cancel
- Edge cases

## Prerequisites

Banking and card operations are scoped to a **company**. If the user has no formed company yet, redirect to [forming-a-company.md](forming-a-company.md) first.

To check: use the company-list tool from `tools/list` (match by description). If the user's account has no companies, form one before continuing.

## Open a bank account

```
- [ ] List existing accounts (so you don't duplicate)
- [ ] Create the account using the account-create tool from tools/list
- [ ] Read the tool's input schema for valid account-type values (the npm README lists "checking", "savings", "wallet" as supported categories — the schema's enum is authoritative)
- [ ] Confirm with user before calling
- [ ] Save the returned account reference
```

Type guidance (general banking terminology — use the tool's actual enum values when calling):

| Type | Use |
|---|---|
| **checking** | Day-to-day operating cash. Cards fund from here. |
| **savings** | Reserve / runway. |
| **wallet** | Programmatic balance for integrations. |

Don't open multiple accounts of the same type without a reason. Ask the user why they need a second checking account before creating one.

## Issue a card

```
- [ ] Confirm which account funds the card → account reference
- [ ] Choose type: "virtual" (instant) or "physical" (mailed, requires address)
- [ ] If physical: confirm mailing address with user before calling
- [ ] Use the card-issue tool from tools/list
- [ ] Save the returned card reference
- [ ] Optional: set spending limit (use the relevant limit-setting tool; valid limit kinds come from its input schema)
```

Card types (sourced from npm README — "Issue virtual/physical cards"):

| Type | Use |
|---|---|
| **virtual** | Online subscriptions, SaaS, ads. Available without shipping. |
| **physical** | In-person payments. Ships to a US address. |

For spending limits: use the tool's input schema to discover valid limit kinds (per-transaction, daily, monthly, or whatever Lovie supports). Don't hard-code limit kinds — discover them from the schema.

## Transfer funds

```
- [ ] Source account reference
- [ ] Destination account reference (Lovie internal or linked external)
- [ ] Amount in USD (from user)
- [ ] STOP and confirm exact values with user before calling
- [ ] Execute via the transfer tool from tools/list → save the returned transfer reference
```

For external destinations, the destination must be a connected linked account — see [transactions-linked-accounts.md](transactions-linked-accounts.md).

Transfer speeds and any fees are returned by the tool — never assert specific timings in your response unless they come from a tool response.

## Deposit funds

```
- [ ] Destination account reference
- [ ] Source: linked external account, wire, or check (whichever the tool supports — see input schema)
- [ ] Amount in USD
- [ ] Confirm with user
- [ ] Execute → save the returned deposit reference
```

Deposit methods, processing times, and any fees come from the tool response.

## Withdraw funds

Withdrawals move funds OUT of a Lovie account to a linked external account.

```
- [ ] Source account reference
- [ ] Destination: linked external account reference
- [ ] Amount in USD
- [ ] Confirm with user
- [ ] Execute → save the returned withdrawal reference
```

Withdrawal speeds and fees come from the tool response.

## Destructive operations — freeze, close, cancel

These cannot be undone trivially. Confirm with user before calling.

### Freeze a card

Use the card-freeze tool from `tools/list` — temporarily blocks all charges. Reversible via the card-unfreeze tool. Use for "I lost my card" or "Why is this vendor still charging?"

### Cancel a card

Permanent. Issues a new card if the user wants. Use when the card is compromised or no longer needed. Confirm with user before calling.

### Freeze a bank account

Blocks all in/out. Reversible. Use for fraud investigation or audit.

### Close a bank account

Permanent. Account balance must be zero. If non-zero, the tool will reject the call — move funds out first.

```
- [ ] Verify account balance = 0 (via the balance-fetch tool)
- [ ] If non-zero: transfer to another account, then close
- [ ] Confirm with user
- [ ] Execute close
```

## Edge cases

**User wants to issue a card BEFORE opening a bank account.** Cards must be funded from an account. Redirect: "You need a checking account to fund the card. Open one now?"

**User wants to transfer to a non-Lovie account.** Connect the external bank via Plaid first (see [transactions-linked-accounts.md](transactions-linked-accounts.md)). Then transfer.

**Multiple companies, which account?** Always confirm which company's account is being operated. Different companies = separate account pools.

**User asks "what's my balance across all accounts?"** List all accounts, then sum the balances. Surface as a short summary: total across N accounts, broken down by type. Use the actual values from the tool responses.

**User asks to "give me money from the company".** This is a distribution — for LLC it's a member draw; for Corp it's a dividend or payroll. The mechanism depends on the entity type and has tax implications. Don't just transfer to a personal account without clarifying. Ask: "Is this a payroll payment, owner draw, or expense reimbursement?" Then refer the user to their accountant if they're unsure.

**Card fraud / unauthorized charge.** Freeze the card immediately via the card-freeze tool. Then file a dispute via whichever dispute tool exists (check `tools/list`). If no dispute tool is exposed, direct the user to `support@lovie.co`.
