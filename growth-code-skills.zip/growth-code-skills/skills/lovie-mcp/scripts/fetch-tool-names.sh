#!/usr/bin/env bash
# Lovie MCP tool discovery — print real tool names via JSON-RPC tools/list.
#
# Usage:
#   bash scripts/fetch-tool-names.sh                # print as markdown table
#   bash scripts/fetch-tool-names.sh --json         # print raw tools array JSON
#   bash scripts/fetch-tool-names.sh --names-only   # print one tool name per line (prefixed)
#
# Requires: jq, npx (or globally installed lovie), and a logged-in lovie account.

set -uo pipefail

# Pick lovie command
if command -v lovie >/dev/null 2>&1; then
  LOVIE_CMD="lovie"
else
  LOVIE_CMD="npx -y lovie"
fi

# Pre-check: jq present
if ! command -v jq >/dev/null 2>&1; then
  echo "Error: jq is required. Install with 'brew install jq' (macOS) or your package manager." >&2
  exit 1
fi

# Don't pre-check login status — the lovie MCP gracefully returns a single
# `lovie_auth_required` stub tool when unauthenticated, which we detect below
# and turn into a clear error message.

# Build JSON-RPC sequence
INIT='{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"fetch-tool-names","version":"1.0"}}}'
INITED='{"jsonrpc":"2.0","method":"notifications/initialized"}'
LIST='{"jsonrpc":"2.0","id":2,"method":"tools/list"}'

# Send, capture stdout. Close stdin after sending so lovie exits.
RESPONSE=$(printf '%s\n%s\n%s\n' "$INIT" "$INITED" "$LIST" | $LOVIE_CMD 2>/dev/null || true)

# Extract the tools/list response (id == 2)
TOOLS_JSON=$(echo "$RESPONSE" | jq -c 'select(.id == 2) | .result.tools' 2>/dev/null | head -n 1)

if [ -z "$TOOLS_JSON" ] || [ "$TOOLS_JSON" = "null" ]; then
  echo "Error: did not receive a valid tools/list response." >&2
  echo "Raw output:" >&2
  echo "$RESPONSE" >&2
  exit 1
fi

# Detect the auth-required stub: when not logged in, the lovie MCP returns a
# single tool named `lovie_auth_required` instead of the real catalog.
if [ "$(echo "$TOOLS_JSON" | jq 'length')" = "1" ] && \
   [ "$(echo "$TOOLS_JSON" | jq -r '.[0].name')" = "lovie_auth_required" ]; then
  echo "Not logged in to Lovie. Run: $LOVIE_CMD login" >&2
  echo "(The Lovie MCP returns a single auth-required stub tool until you authenticate.)" >&2
  exit 2
fi

# Output mode
MODE="${1:---table}"
case "$MODE" in
  --json)
    echo "$TOOLS_JSON" | jq '.'
    ;;
  --names-only)
    echo "$TOOLS_JSON" | jq -r '.[].name'
    ;;
  --table|"")
    echo "| Tool | Description |"
    echo "|---|---|"
    echo "$TOOLS_JSON" | jq -r '.[] | "| \(.name) | \((.description // "no description") | gsub("\n"; " "; "g")) |"'
    ;;
  *)
    echo "Unknown mode: $MODE" >&2
    echo "Usage: $0 [--table|--json|--names-only]" >&2
    exit 2
    ;;
esac
