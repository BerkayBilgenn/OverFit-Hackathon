#!/usr/bin/env bash
# Lovie MCP preflight check — verify Node, lovie install, login, and Claude Code wiring.
#
# Usage:
#   bash scripts/preflight.sh
#
# Exit codes:
#   0 — all checks passed
#   1 — one or more checks failed

set -uo pipefail

PASS="[OK]"
FAIL="[!!]"
SKIP="[--]"

results=()
fail_count=0

# 1) Node.js version
if command -v node >/dev/null 2>&1; then
  v=$(node --version | sed 's/^v//')
  major=${v%%.*}
  if [ "$major" -ge 18 ]; then
    results+=("$PASS Node v$v (>=18)")
  else
    results+=("$FAIL Node v$v (need >=18)")
    fail_count=$((fail_count + 1))
  fi
else
  results+=("$FAIL Node not installed")
  fail_count=$((fail_count + 1))
fi

# 2) lovie binary or npx
LOVIE_CMD=""
if command -v lovie >/dev/null 2>&1; then
  LOVIE_CMD="lovie"
  results+=("$PASS lovie binary on PATH")
elif command -v npx >/dev/null 2>&1; then
  LOVIE_CMD="npx -y lovie"
  results+=("$PASS npx available (will use 'npx -y lovie')")
else
  results+=("$FAIL Neither lovie nor npx found")
  fail_count=$((fail_count + 1))
fi

# 3) Login status — match the negative form, which is the only string we have verified live.
# `lovie status` returns "Not logged in. Run: npx lovie login" when unauthenticated.
# The success-path string is not verified by this skill, so we treat its absence as success.
if [ -n "$LOVIE_CMD" ]; then
  status_out=$($LOVIE_CMD status 2>&1 || true)
  if echo "$status_out" | grep -qiE "Not logged in|not authenticated|please log ?in"; then
    results+=("$FAIL Not logged in (run: $LOVIE_CMD login)")
    fail_count=$((fail_count + 1))
  else
    results+=("$PASS lovie status reports no auth failure")
  fi
else
  results+=("$SKIP Login check skipped (no lovie/npx)")
fi

# 4) Claude Code MCP wiring
if command -v claude >/dev/null 2>&1; then
  if claude mcp list 2>&1 | grep -q "^lovie"; then
    results+=("$PASS Lovie wired into Claude Code")
  else
    results+=("$FAIL Lovie not wired into Claude Code")
    results+=("     fix: claude mcp add --scope user lovie -- npx -y lovie")
    fail_count=$((fail_count + 1))
  fi
else
  results+=("$SKIP Claude Code CLI not detected (skipping wiring check)")
fi

# 5) Lovie MCP server reachable (DNS + TLS)
if command -v curl >/dev/null 2>&1; then
  url="${LOVIE_MCP_URL:-https://lovie-mcp.vercel.app/mcp/mcp}"
  if curl -sS -o /dev/null -w "%{http_code}" --max-time 10 "$url" 2>&1 | grep -qE "^(2|3|4)[0-9]{2}$"; then
    results+=("$PASS Lovie MCP server reachable ($url)")
  else
    results+=("$FAIL Lovie MCP server unreachable ($url)")
    fail_count=$((fail_count + 1))
  fi
else
  results+=("$SKIP curl not installed (skipping server reachability check)")
fi

echo ""
echo "Lovie MCP preflight"
echo "-------------------"
for r in "${results[@]}"; do
  echo "  $r"
done
echo ""

if [ "$fail_count" -gt 0 ]; then
  echo "Failed: $fail_count check(s). See lines marked $FAIL above."
  exit 1
fi
echo "All checks passed."
exit 0
