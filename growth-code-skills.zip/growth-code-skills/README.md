# Growth Code Skills Pack

Lovie **Growth-main** deposunda kod yazan bir AI'ın yüklemesi gereken 48 skill + projenin
çalışma kuralları. Tek klasör, tek zip, hiçbir gizli bilgi yok.

Paket **Claude'a özel değil**: her skill düz Markdown (`SKILL.md` + yardımcı `.md`/`scripts`).
Cursor, Codex, Gemini CLI, Windsurf veya kendi harness'ın — hepsi okuyabilir.

---

## İçindekiler

| Klasör | Ne var |
|---|---|
| `skills/` | 48 skill, her biri kendi klasöründe `SKILL.md` ile |
| `project-rules/CLAUDE.md` | Growth-main'in operating model'i — üç prensip, `specs/` düzeni, superpowers öncelik kuralları, brainstorming HARD-GATE |
| `project-rules/AGENTS.md` | Aynı kuralların Codex/Antigravity aynası (depoda `AGENTS.md` → `.antigravity-rules.md` sembolik linki) |
| `project-rules/specs-README.md` | `specs/` altındaki 8 motorun (platform, slm, subhunter, tokenops, hackhunter, lead-research, pool, cockpit) haritası |

Skill listesinin tamamı ve tek satırlık açıklamaları: **[INDEX.md](INDEX.md)**

### Dört grup

**1. Mühendislik süreci — 14 skill (superpowers 6.3.0)**
İşin nasıl yürüdüğünü belirler; en önemli grup budur.
`brainstorming` · `writing-plans` · `executing-plans` · `subagent-driven-development` ·
`dispatching-parallel-agents` · `test-driven-development` · `systematic-debugging` ·
`requesting-code-review` · `receiving-code-review` · `verification-before-completion` ·
`finishing-a-development-branch` · `using-git-worktrees` · `using-superpowers` · `writing-skills`

**2. UI / design engineering — 28 skill**
Depo ağırlıklı Next.js + Tailwind kokpit olduğu için asıl kod kalitesi farkını burada görürsün.
`better-ui` · `better-layout` · `better-typography` · `better-colors` · `better-accessibility` ·
`better-writing` · `better-interface` · `baseline-ui` · `interface-review` · `improve-ui` ·
`create-design-md` · `design-system` · `ui-styling` · `ui-ux-pro-max` · `ui-skills-root` ·
`pick-ui-library` · `prototype` · `apple-design` · `emil-design-eng` · `animate` ·
`review-animations` · `improve-animations` · `find-animation-opportunities` ·
`animation-vocabulary` · `fixing-accessibility` · `fixing-motion-performance` ·
`fixing-metadata` · `lovie-mcp`

**3. Projenin çalışma prensipleri — 3 skill**
`ai-first` · `artifact-first` · `async-first` — CLAUDE.md bunları *her* görevde yürürlükte sayar.

**4. Geliştirme desteği — 3 skill**
`documentation-lookup` (Context7 ile güncel kütüphane dokümanı) · `exa-search` · `deep-research`

---

## Kurulum

### Claude Code — yalnızca bu proje için
```bash
unzip growth-code-skills-pack.zip
cp -R growth-code-skills/skills/* /yol/Growth-main/.claude/skills/
```

### Claude Code — tüm projeler için
```bash
mkdir -p ~/.claude/skills && cp -R growth-code-skills/skills/* ~/.claude/skills/
```

### Cursor / Codex / Antigravity (`.agents` standardı)
```bash
mkdir -p ~/.agents/skills && cp -R growth-code-skills/skills/* ~/.agents/skills/
# proje köküne kuralları da bırak:
cp growth-code-skills/project-rules/AGENTS.md /yol/proje/AGENTS.md
```

### Gemini CLI
```bash
cp -R growth-code-skills/skills/* ~/.gemini/skills/
cp growth-code-skills/project-rules/CLAUDE.md /yol/proje/GEMINI.md
```

### Skill mekanizması olmayan herhangi bir AI
`skills/<ad>/SKILL.md` dosyalarını doğrudan sistem prompt'una veya bağlamına yapıştır.
Hepsini birden yükleme — `INDEX.md`'deki açıklamalardan göreve uyan 2-3 tanesini seç.
`using-superpowers` skill'i bu seçimin nasıl yapılacağını anlatır; onu her zaman yükle.

---

## Öncelik kuralları (CLAUDE.md'den)

İki skill aynı alanı kapsıyorsa **superpowers kazanır**:

- `writing-plans` > herhangi bir planlama akışı
- `systematic-debugging` > herhangi bir hata ayıklama akışı
- `using-git-worktrees` > git worktree yönergeleri
- `test-driven-development` — implementasyon kodu yazılan **her** yerde

### Brainstorming HARD-GATE

`brainstorming`, "tasarım sunulup onaylanmadan kod yok" kuralını dayatır. **Yürürlükte:**
yeni feature/route/endpoint, davranış değiştiren refactor, şema/migration işi, birden fazla
dosyanın niyetine dokunan her görev.

**Yürürlükte değil:** tek dosyalık bug fix, kopya düzeltmesi, küçük UI rötuşu, "şunu bir dene,
sonra iterasyon yaparız" diye çerçevelenmiş WIP, tek satırlık config değişikliği, typo,
bağımlılık yükseltmesi, salt-okunur araştırma/denetim.

Emin değilsen bir soru sor; kullanıcıya görünen her şeyde varsayılan **kapı açık**tır.

### Tasarım dokümanı konumu

`brainstorming` tasarım dokümanı yazarken plugin varsayılanı (`docs/superpowers/specs/`) yerine
`specs/<motor>/superpowers/specs/YYYY-MM-DD-<konu>-design.md` kullanılır.

---

## Dış bağımlılıklar

Çoğu skill saf Markdown, hiçbir şey istemez. İstisnalar:

| Skill | Gereksinim |
|---|---|
| `documentation-lookup` | Context7 MCP sunucusu |
| `exa-search` | Exa MCP sunucusu |
| `deep-research` | firecrawl + exa MCP sunucuları |
| `ui-ux-pro-max` | `python3` (yerel JSON veritabanını sorgulayan scriptler) |
| `ui-skills-root` | `npx ui-skills` |
| `lovie-mcp` | Lovie MCP sunucusu |

MCP'si olmayan bir AI'da bu 4 skill sessizce işe yaramaz olur; diğer 44'ü etkilemez.

---

## Pakette bilerek olmayanlar

- **`ui-styling/canvas-fonts/`** (5.5 MB font) — yalnızca canvas poster üretimi için;
  kod yazmaya katkısı yok, zip'i 6 kat şişiriyordu. Gerekirse orijinal skill'den kopyala.
- **İçerik/pazarlama/yatırımcı skill'leri** — `article-writing`, `brand-voice`,
  `content-engine`, `crosspost`, `humanizer`, `investor-materials`, `investor-outreach`,
  `market-research`, `x-api`, `culture-expert`, `culture-os`. Kod yazmayla ilgileri yok.
- **Depo sırları** — `.env.local`, kimlik bilgileri, veri dökümleri. Paket taranmış, temiz.

---

*Kaynak: Growth-main @ `feat/product-dashboards-common-grammar`. superpowers 6.3.0.*
