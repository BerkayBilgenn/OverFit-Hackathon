---
summary: "Index of specs/: lists the eleven engine/domain folders (platform, slm, subhunter, tokenops, hackhunter, lead-research, pool, vibehouse, parks, agenthunt, cockpit), each holding curated root docs plus a dated superpowers/{specs,plans} journal, and points to mailable-filters.md as the cross-engine gate reference."
tags: [platform]
up: "[[maps/Platform]]"
---
# specs/ — Growth Main Specifications
> [!summary]
> Index of specs/: lists the eleven engine/domain folders (platform, slm, subhunter, tokenops, hackhunter, lead-research, pool, vibehouse, parks, agenthunt, cockpit), each holding curated root docs plus a dated superpowers/{specs,plans} journal, and points to mailable-filters.md as the cross-engine gate reference.

Per-engine specifications for the Growth Main monorepo (Lovie's internal growth/lead cockpit).

Mirrors the [`lovie`](../../lovie) monorepo convention — **curated specs at the domain root, the dated Superpowers build-journal under `superpowers/`** — adapted to Growth Main. Growth Main is FastAPI engines + a Next.js cockpit with **no proto/ConnectRPC codegen**, so lovie's manifest/feature-triad/RPC machinery is intentionally *not* reproduced here (see `AGENTS.md`).

## Layout

Each engine/domain folder holds:

- **Curated docs at the root** — the durable "what": product specs, architecture, schema, checklists.
- **`superpowers/specs/`** — dated design docs (`YYYY-MM-DD-<topic>-design.md`), audits, analyses.
- **`superpowers/plans/`** — dated implementation plans (`YYYY-MM-DD-<topic>-plan.md`).

## Domains (folder ≡ service / app)

| Folder | What | Code |
|---|---|---|
| `platform/` | Cross-cutting: vision, platform scope, tech stack, GDPR, secrets, system diagrams, deployment | — |
| `slm/` | **SniperLaunchMaker** — launch-scan → matched, no-CTA outreach | `services/slm-api` |
| `subhunter/` | **Subdomains** — CT-log AI-app-builder subdomain lead engine | `services/subhunter-api` |
| `tokenops/` | **TokenOps Growth Engine** — AI-spend B2B lead pipeline | `services/tokenops-api` |
| `hackhunter/` | **HackHunter** — hackathon-platform lead engine. Part of the **Hackathon Growth** family since 2026-08-07 (it was a Formation source before); the folder stays here because it maps to the service, and the service did not move. | `services/hackhunter-api` |
| `lead-research/` | **Lead Research / TargetLeads** — quality, scoring, enrichment | `services/lead-research-api` |
| `pool/` | **Unified email pool** — dedup, mailable gate, Clay push | `services/pool-api`, `services/email-pool` |
| `vibehouse/` | **Vibe House Sponsor Radar** — event-sponsor prospecting + CRM | `vibehouse-sponsors/`, cockpit `/vibe-house` |
| `parks/` | **Parks Directory** — global science/tech-park directory, frozen dataset, no backend | `data/parks/`, cockpit `/parks` |
| `agenthunt/` | **AgentHunt** — US business-formation filing cohorts, keyed on the registered-agent address. Phase 1 (2026-08-26) is the Wyoming quarterly ingest; the cockpit surface is Phase 2. | `services/agenthunt-api` |
| `cockpit/` | **Operator cockpit** — dashboards, leads flow | `apps/growth-main` |

Product aliases: `slm` ≡ SniperLaunchMaker (SLM) · `subhunter` ≡ Subdomains · `pool` ≡ email-pool.

## Cross-engine references

- [`mailable-filters.md`](mailable-filters.md) — canonical per-engine "mailable" / Clay-push gate reference (what filters a lead must pass to be mailed). Update on every gate change.

## Runtime assets

`content-library/` (repo root — **not** here) holds runtime assets consumed by `slm-api` (pain-point hooks index, culture / voice / golden-set). It is data, not documentation; keep it out of `specs/`.

## Authoring

See `AGENTS.md` for the contract. Start new docs from `_template/`.
