---
summary: "Canonical operating model for this repo: the AI-First/Artifact-First/Async-First principles, the specs/ project layout, and the superpowers plugin workflow (brainstorming hard-gate, precedence rules, per-engine spec-location override)."
tags: [platform]
up: "[[maps/Platform]]"
---
# Lovie Growth — Operating Model
> [!summary]
> Canonical operating model for this repo: the AI-First/Artifact-First/Async-First principles, the specs/ project layout, and the superpowers plugin workflow (brainstorming hard-gate, precedence rules, per-engine spec-location override).

This project runs on Lovie's **Future of Work 2.0** culture. Every task in this codebase follows three operating principles. They are not optional and apply to all collaborators, including AI agents.

## The Three Principles

1. **AI-First** — `.claude/skills/ai-first/SKILL.md`
   Default to AI-augmented workflows. Don't ask "how do I do this?" — ask "how do we do this together, faster and better?"

2. **Artifact-First** — `.claude/skills/artifact-first/SKILL.md`
   The artifact (doc, design, code, recording) IS the work, not a byproduct. If it isn't a searchable artifact, it didn't happen. Document in Notion first, then communicate via Slack.

3. **Async-First** — `.claude/skills/async-first/SKILL.md`
   Default to asynchronous, written communication. Provide thorough context in every output. Escalate to sync only after the 3x Rule is exhausted.

## How AI Agents Must Operate Here

When working in this project, embody all three principles simultaneously:

- **Produce a searchable artifact as the primary output of every task** — not just a chat reply. Structure outputs with clear headings and metadata so future readers (human or AI) can discover and build on them.
- **Search existing artifacts before generating new ones.** Check `specs/` (per-engine specs) and existing Notion docs before drafting from scratch. Cite sources with links.
- **Default to written, self-contained communication.** Assume the reader is asleep in another timezone. Include context, links, the ask, and the expected next step.
- **Proactively suggest AI-augmented approaches** when the user describes a manual workflow.
- **Iterate rapidly over polishing.** Ship a draft early with a "work-in-progress" marker; refine through feedback rather than aiming for first-draft perfection.
- **Default to building tools** rather than recommending SaaS purchases when a simple internal tool would solve the need.

For the full operating principles, read the corresponding `SKILL.md` files. The skills auto-load when their descriptions match a request, but their guidance is in force on every task in this project regardless of whether the skill is explicitly invoked.

## Project Layout

- `specs/` — Per-engine specifications (`platform`, `slm`, `subhunter`, `tokenops`, `hackhunter`, `lead-research`, `pool`, `cockpit`); see `specs/README.md`. Source of truth for product, architecture, schema, and roadmap.
- `.claude/skills/` — Operating-principle skills (ai-first, artifact-first, async-first).

## Superpowers Plugin

The `superpowers` plugin (obra/superpowers) is installed. It contributes `superpowers:*` skills covering brainstorming → spec → plan → TDD → subagent execution → review → finish. When two skills cover the same area, `superpowers:*` takes precedence:

- `superpowers:writing-plans` over `workflow-planning`
- `superpowers:systematic-debugging` over `workflow-debugging`
- `superpowers:using-git-worktrees` over the worktree parts of `workflow-git`
- `superpowers:test-driven-development` whenever writing implementation code

### Brainstorming HARD-GATE override

`superpowers:brainstorming` enforces a HARD-GATE: "no code, no implementation skill until a design is presented and approved." This is in force for:

- New features, components, routes, or endpoints
- Behavior-changing refactors
- Schema or migration work
- Any task that touches more than one file's intent

This is **NOT** in force for:

- Single-file bug fixes, copy edits, small UI tweaks
- WIP iterations explicitly framed as "just try this, we'll iterate"
- One-line config changes, typo fixes, dependency bumps
- Read-only investigation, audits, or research tasks

When unsure, ask one clarifying question; default to gate-on rather than gate-off for anything user-facing.

### Spec location override

When `superpowers:brainstorming` writes design docs, save them under `specs/<engine>/superpowers/specs/YYYY-MM-DD-<topic>-design.md` (pick the engine folder the design targets; see `specs/README.md`) rather than the plugin default (`docs/superpowers/specs/`). Keeps each design co-located with its engine's specs.
